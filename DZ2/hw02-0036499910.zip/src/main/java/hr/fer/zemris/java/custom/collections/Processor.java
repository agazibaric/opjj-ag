package hr.fer.zemris.java.custom.collections;

public class Processor {
	
	public void process(Object value) {
		
	}
	
}
