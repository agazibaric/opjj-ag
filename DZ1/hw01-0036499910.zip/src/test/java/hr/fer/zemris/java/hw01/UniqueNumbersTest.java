package hr.fer.zemris.java.hw01;

import org.junit.Assert;
import org.junit.Test;
import hr.fer.zemris.java.hw01.UniqueNumbers.TreeNode;

/**
 * Tests for methods from UniqueNumber class 
 * that are used for adding element to binary tree, 
 * calculating size of a binary tree,
 * and checking if the binary tree contains a given value.
 * 
 * @author Ante Gazibarić
 *
 */
public class UniqueNumbersTest {
	
	@Test
	public void forSpecificBinaryTreeSize() {
		TreeNode head = null;
		head = UniqueNumbers.addNode(head, 5);
		head = UniqueNumbers.addNode(head, 4);
		head = UniqueNumbers.addNode(head, 7);
		
		int expectedSize = 3;
		int actualSize = UniqueNumbers.treeSize(head);
		
		Assert.assertEquals(expectedSize, actualSize);
	}
	
	@Test
	public void forAddingContainedValue() {
		TreeNode head = null;
		head = UniqueNumbers.addNode(head, 5);
		head = UniqueNumbers.addNode(head, 5);
		head = UniqueNumbers.addNode(head, 7);
		
		int expectedSize = 2;
		int actualSize = UniqueNumbers.treeSize(head);

		Assert.assertEquals(expectedSize, actualSize);
	}
	
	@Test
	public void forEmptyBinaryTreeSize() {
		int expectedSize = 0;
		TreeNode head = null;
		int actualSize = UniqueNumbers.treeSize(head);
		
		Assert.assertEquals(expectedSize, actualSize);
	}
	
	@Test 
	public void forContainedElement() {
		int element = 5;
		TreeNode head = null;
		head = UniqueNumbers.addNode(head, element);

		boolean condition = UniqueNumbers.containsValue(head, element);
		
		Assert.assertTrue(condition);
	}
	
	@Test
	public void forNotContainedElement() {
		int element = 5;
		TreeNode head = null;
		head = UniqueNumbers.addNode(head, element);
		
		boolean condition = !UniqueNumbers.containsValue(head, 6);
		
		Assert.assertTrue(condition);
	}
	
	@Test
	public void forReturnReferenceAfterAddingElement() {
		TreeNode firstHead = null;
		TreeNode secondHead = null;
		firstHead = UniqueNumbers.addNode(firstHead, 5);
		secondHead = UniqueNumbers.addNode(firstHead, 6);
		
		Assert.assertEquals(firstHead, secondHead);
	}
	
	
	
}
