package hr.fer.zemris.java.hw01;

import org.junit.Assert;
import org.junit.Test;

/**
 * Tests for method from Factorial class which calculates factorial of a given number.
 * 
 * @author Ante Gazibarić
 *
 */
public class FactorialTest {
	
	@Test
	public void forSpecificNumber() {
		Long expected = 120L;
		Long actual = Factorial.getFactorial(5);
		Assert.assertEquals(expected, actual);
	}
	
	@Test 
	public void forNumberZero() {
		Long expected = 1L;
		Long actual = Factorial.getFactorial(0);
		Assert.assertEquals(expected, actual);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void forNegativeNumber() {
		Factorial.getFactorial(-5);
	}
	
}
