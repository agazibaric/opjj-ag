package hr.fer.zemris.java.hw01;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import java.util.Scanner;

/**
 * Program that calculates area and circumference of a rectangle with given width and height.
 * The width and the height are given by the user through command line or through standard input.
 * The program checks if the values are correct for calculation and prints out the result on the screen.
 * 
 * @author Ante Gazibarić
 * @version 1.0
 */
public class Rectangle {
	
	public static void main(String[] args) {
		
		if(args.length == 2) {
			
			Double width = getValue(args[0]);
			Double height = getValue(args[1]);
			
			if(width != null && height != null) {
				calculateAndPrint(width, height);
			}
			
		} else if(args.length == 0) {
			getUserInput();
			
		} else {
			System.err.println("Unijeli ste nevažeći broj argumenata.");
			System.exit(1);
		}
		
	}
	
	/**
	 * Method that takes and verifies user input through standard input.
	 * It calculates and prints area and circumference of a rectangle.
	 */
	private static void getUserInput() {
		Scanner scanner = new Scanner(System.in);
		Double width, height;
		
			do {
				System.out.print("Unesite širinu > ");
				String userInput = scanner.next();
			    width = getValue(userInput);
			} while(width == null);
			
			do {
				System.out.print("Unesite visinu > ");
				String userInput = scanner.next();
				height = getValue(userInput);
			} while(height == null);
		
		calculateAndPrint(width, height);
		
		scanner.close();
	}
	
	/**
	 * This method calculates and prints area and circumference of rectangle.
	 * Area of rectangle = width * height
	 * Circumference of rectangle = 2 * (width + height)
	 * 
	 * @param width   width of rectangle
	 * @param height  height of rectangle
	 */
	private static void calculateAndPrint(Double width, Double height) {
		Double areaOfRectanlge = width * height;
		Double circumferenceOfRectangle = 2 * (width + height);
		
		System.out.format("Pravokutnik širine %.1f i visine %.1f ima površinu %.1f te opseg %.1f.", 
							width, height, areaOfRectanlge, circumferenceOfRectangle);
		
	}
	
	/**
	 * Method takes value as an argument and checks if the value is convertible into a Double.
	 * If it's convertible and nonnegative it returns converted value as a Double, otherwise 
	 * it returns <code>null</code> and prints suitable message.
	 * 
	 * @param value  String type argument of method that goes through Double conversion process
	 * @return       Double value of method's argument or <code>null</code> if it's unconvertible or negative 
	 */
	private static Double getValue(String value) {
		Double number = null;
		
		try {
			number = getLocalFormat(value);
			
			if(number < 0) {
				System.out.println("Unijeli ste negativnu vrijednost.");
				return null;
			} else if(number == 0) {
				System.out.println("Iznos stranice pravokutnika ne može biti nula.");
				return null;
			}
			
		} catch(ParseException ex) {
			System.out.println("'" + value + "' se ne može protumačiti kao broj.");
		}
		
		return number;
	}
	
	/**
	 * This method takes a String as an argument and converts it into a Double value 
	 * which is consistent with current localization settings.
	 * 
	 * @param value            value that is converted into a Double
	 * @return                 Double value of method's argument 
	 * 						   that is consistent with current localization settings
	 * @throws ParseException  if the beginning of the specified string cannot be parsed;
	 * 						   due to the parse method called on NumberFormat object
	 */
	private static Double getLocalFormat(String value) throws ParseException {
		Locale local = Locale.getDefault(Locale.Category.FORMAT);
		NumberFormat numberFormat = NumberFormat.getNumberInstance(local);
		
		return numberFormat.parse(value).doubleValue();
	}
	
}

