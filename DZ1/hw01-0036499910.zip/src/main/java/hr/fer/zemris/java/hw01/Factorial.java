package hr.fer.zemris.java.hw01;

import java.util.Scanner;

/**
 * Program that calculates a factorial of a given number.
 * The number is given by the user through standard input.
 * The program verifies if the number is consistent with the rules needed for factorial calculation
 * and it prints the result on the screen. 
 * The program ends when the user inputs "kraj".
 * 
 * @author Ante Gazibarić
 * @version 1.0
 */

public class Factorial {
	
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.print("Unesite broj > ");
			String userInput = scanner.next();
			
			if (userInput.toLowerCase().equals("kraj")) {
				System.out.println("Doviđenja.");
				break;
			}
			
			try {
				int number = Integer.parseInt(userInput);
				
				if(number < 1 || number > 20) {
					System.out.println("'" + number + "' nije broj u dozvoljenom rasponu.");
					continue;
				}
				
				Long factorialOfNumber = getFactorial(number);
				System.out.println(number + "! = " + factorialOfNumber);
				
			} catch(NumberFormatException ex) {
				System.out.println("'" + userInput + "' nije cijeli broj.");
			} catch(IllegalArgumentException ignorable) {
				//In this example this will never happen 
				//due to the previous check for negative numbers
			}

		}
		
		scanner.close();

	}
	
	
	
	
	/**
	 * Method that returns a factorial of a given number.
	 * 
	 * @param number  				     number whose factorial is calculated
	 * @return 		 				     factorial of a given number
	 * @throws IllegalArgumentException  if a given number is negative
	 */
	public static Long getFactorial(int number) throws IllegalArgumentException {
		if(number < 0) {
			throw new IllegalArgumentException("Factorial of a negative number can not be calculated.");
		}
		Long factorialOfNumber = 1L;
		
		while(number > 0) {
			factorialOfNumber *= number;
			number--;
		}
		
		return factorialOfNumber;
	}
	
	
}
