package hr.fer.zemris.java.hw01;

import java.util.Scanner;

/**
 * Program that takes integers from user through standard input
 * and stores them into a binary tree.
 * If the number is not integer the program prints suitable message,
 * ignores inputed value and continues with the input process.
 * The user completes his input by typing: "kraj".
 * The program then prints the inputed numbers in ascending and descending order.
 * 
 * @author Ante Gazibarić
 * @version 1.0
 */
public class UniqueNumbers {
	
	/**
	 * Class that represents node in a binary tree.
	 * Values that nodes can store are integers.
	 * 
	 * @author Ante Gazibarić
	 */
	public static class TreeNode {
		TreeNode left, right;
		int value;
	}
	
	/**
	 * This method adds a value into a given binary tree 
	 * only if that tree doesn't already contain that value.
	 * 
	 * @param head   head of a binary tree to which value is added
	 * @param value  value that is added in a given binary tree
	 * @return       head of a binary tree
	 */
	public static TreeNode addNode(TreeNode head, int value) {
		if(head == null) {
			head = new TreeNode();
			head.left = head.right = null;
			head.value = value;
			return head;
		}
		
		if(value < head.value) {
			head.left = addNode(head.left, value);
			
		} else if(value > head.value) {
			head.right = addNode(head.right, value);
		}
		
		return head;
	}
	
	/**
	 * This method returns number of elements in the binary tree.
	 * 
	 * @param head  head of binary tree whose size is calculating
	 * @return		number of elements in a given binary tree
	 */
	public static int treeSize(TreeNode head) {
		if(head == null) {
			return 0;
		}
		return 1 + treeSize(head.left) + treeSize(head.right);
	}
	
	/**
	 * This method looks for a value in the binary tree.
	 * Average complexity of this method is O(log n), best case O(1), worst case O(n).
	 * 
	 * @param head   head of binary tree that is being searched
	 * @param value  value that is searched in a given binary tree
	 * @return		 <code>true</code> if the given value is found in the binary tree,
	 * 				 <code>false</code> otherwise.
	 */
	public static boolean containsValue(TreeNode head, int value) {
		if(head == null) {
			return false;
		}
		
		if(value < head.value) {
			return containsValue(head.left, value);
			
		} else if (value > head.value) {
			return containsValue(head.right, value);
			
		} else {
			return true;
		}
	}
	
	/**
	 * This method prints the elements of the given binary tree in ascending order to standard output.
	 * 
	 * @param head  head of binary tree whose elements are printed
	 */
	public static void printInOrder(TreeNode head) {
		if(head == null) {
			return;
		}
		
		printInOrder(head.left);
		System.out.print(head.value + " ");
		printInOrder(head.right);
	}
	
	/**
	 * This method prints the elements of the given binary tree in descending order to standard output.
	 * 
	 * @param head  head of binary tree whose elements are printed
	 */
	public static void printInReverseOrder(TreeNode head) {
		if(head == null) {
			return;
		}
		
		printInReverseOrder(head.right);
		System.out.print(head.value + " ");
		printInReverseOrder(head.left);
	}
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		TreeNode glava = null;
		
		while(true) {		
			System.out.print("Unesite broj > ");
			String userInput = scanner.next();
			
			if(userInput.toLowerCase().equals("kraj")) {
				break;
			}
			
			try {
				Integer number = Integer.parseInt(userInput);
				
				if(!containsValue(glava, number)) {
					glava = addNode(glava, number);
					System.out.println("Dodano.");
					
				} else {
					System.out.println("Broj već postoji. Preskačem.");
				}
				
			} catch(NumberFormatException ex) {
				System.out.println("'" + userInput + "' nije cijeli broj.");
			}
			
		}
		
		System.out.print("Ispis od najmanjeg: ");
		printInOrder(glava);
		
		System.out.print("\nIspis od najvećeg: ");
		printInReverseOrder(glava);
		System.out.println("");
		
		scanner.close();
		
	}
	
}
